@extends('layout.master')

@section ('content')

               Dashboard
@stop
