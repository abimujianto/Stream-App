<nav class="navbar navbar-default navbar-fixed-top">
    <div class="brand"><a href="/jadwal">Balikpapan Televisi</a></div>
		<div class="container-fluid">
			<div id="navbar-menu">
				
			</div>
         </div>
</nav>