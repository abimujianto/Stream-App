<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<!-- <li><a href="/dashboard" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li> -->
						<li><a href="/jadwal" class="active"><i class="lnr lnr-pencil"></i> <span>Jadwal Siaran</span></a></li>
						<li><a href="/logout" class=""><i class="lnr lnr-exit"></i> <span>Logout</span></a></li>
					</ul>
				</nav>
			</div>
		</div>