<nav class="navbar navbar-default navbar-fixed-top">
    <div class="brand"><a href="/jadwal">Balikpapan Televisi</a></div>
		<div class="container-fluid">
			<div id="navbar-menu">
				
			</div>
         </div>
</nav><?php /**PATH C:\Users\abimu\btvbackend\resources\views/layout/includes/_navbar.blade.php ENDPATH**/ ?>